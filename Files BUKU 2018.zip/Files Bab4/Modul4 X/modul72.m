t=0:1/25:19/25;
s=0.5*sin(2*pi*2.5*t+0.2);

figure(1)
plot(0:length(s)-1,s,'o:');
xlabel('n');
ylabel('x(n)');
%axis([0 20 -0.4 0.4]);

figure(2)
S=fft(s);
stem(0:length(s)-1,(2/length(s))*abs(S));
xlabel('k');
ylabel('|X(k)|');
%axis([0 20 0 0.35]);


