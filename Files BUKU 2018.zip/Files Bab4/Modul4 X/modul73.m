t=0:0.05:1-0.05;
s1=0.5*sin(2*pi*2.5*t+0);
s=s1;

figure(1)
plot(0:length(s)-1,s,'o:');
xlabel('n');
ylabel('x(n)');
axis([0 21 -1 1.5]);

figure(2)
S=fft(s);
stem(0:length(s)-1,abs(S));
xlabel('k');
ylabel('|X(k)|');
axis([0 21 0 6]);

figure(3)
stem(-40:39,[abs(S) abs(S) abs(S) abs(S)]);
axis([-30 30 0 6]);
xlabel('k');
ylabel('|X(k)|');
