[b,a]=fir1(12,600/1000,'low');
h=b;
H=fft(b);
plot(0:(length(H)-1),abs(H),'o-','LineWidth',2,'Color',[0 0 0]);
xlabel('k');
ylabel('|H(k)|');

figure(2);
H=fft(b,1000);
plot(0:(length(H)-1),abs(H),'LineWidth',2,'Color',[0 0 0]);
xlabel('k');
ylabel('|H(k)|');

% plot(W,absH,'LineWidth',2,'Color',[0 0 0]);
% xlabel('f(Hz)');
% ylabel('|H|');
% axis([0 2000 0 1.1]);
% hold on
% plot([0 600],[0.8913 0.8913],':k');
% plot([0 600],[1 1],':k');
% plot([0 800],[0.1 0.1],':k');
% plot([400 400],[0 0.8913],':k');
% text(600,0.94,'\delta_p');
% text(-80,0.1,'\delta_s');
% text(400,-0.1,'f_c');
% hold off


