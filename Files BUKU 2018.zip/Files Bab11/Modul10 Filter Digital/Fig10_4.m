[b,a]=fir1(12,30/1000,'low');
[b,a]=cheby2(10,0.5,50/100,'low');
[b,a]=ellip(3,1,20,40/100,'low');
[H,W]=freqz(b,a);

figure(1)
%subplot(2,1,1);
W=[W*1000/pi; 1000+W*1000/pi];
absH=[abs(H); flipud(abs(H))];
plot(W,absH,'LineWidth',2,'Color',[0 0 0]);
xlabel('\Omega');
ylabel('|H|');
axis([0 2000 0 1.1]);
hold on
plot([0 600],[0.8913 0.8913],':k');
plot([0 600],[1 1],':k');
plot([0 800],[0.1 0.1],':k');
plot([400 400],[0 0.8913],':k');
text(600,0.94,'\delta_p');
text(-80,0.1,'\delta_s');
text(400-20,-0.03,'\Omega_c');
text(2000-40,-0.03,'2\pi');
text(1000-20,-0.03,'\pi');
hold off
% subplot(2,1,2);
% plot(W*100/pi,(angle(H)));
% plot(W*100/pi,unwrap(angle(H)));
% xlabel('f(Hz)');
% ylabel('\phi_h');
% grid

