[b,a]=fir1(12,100/1000,'low');
t=0:1/2000:0.3;
s=2*sin(2*pi*20*t)+0.2*randn(1,length(t));
plot(t,s);
pause
s2=filter(b,a,s);
plot(t,s2);
save sinyal10_4 s