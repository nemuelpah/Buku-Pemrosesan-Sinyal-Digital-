clear all
clc
tn=0:0.001:.2;
sn=0.5*sin(2*pi*23*tn-0); %0.1
t=0:1/84:0.2;%1/127
s=0.5*sin(2*pi*23*t);


figure(1)
plot(tn,sn,':');hold
plot(t,s,'.');hold
xlabel('t (det)');
ylabel('x(t)');
axis([0 1 -1 1]);

figure(2)
S=fft(s);
SA=(2/length(s))*abs(S);
SA(1)=SA(1)/2;
stem([0:length(s)-1]/length(s)*84,SA,'.');
xlabel('f (Hz)');
ylabel('|A|');
axis([0 84 0 0.6]);

s=[s zeros(1,20*length(t))];
S=fft(s);hold
plot([0:length(s)-1]/length(s)*84,(2/length(t))*abs(S),':');hold


