[a,fs]=wavread('dtmf.wav');
plot(a)
pause;

a1=a(80000:83000);

X=fft(a1);
stem(abs(X),'.');


