tn=0:0.001:1;
sn=0.8*sin(2*pi*23*tn-0); %0.1
t=0:1/500:1;%1/127
s=0.8*sin(2*pi*23*t);

figure(1)
plot(tn,sn,':');hold
plot(t,s,'.');hold
xlabel('t (det)');
ylabel('x(t)');
axis([0 1 -1 1]);

figure(2)
S=fft(s);
SA=(2/length(s))*abs(S);
SA(1)=SA(1)/2;
stem([0:length(s)-1]/length(s)*500,SA,'.');
%stem([0:length(s)-1]/length(s)*500,abs(S),'.');
xlabel('f (Hz)');
ylabel('|A|');
%axis([0 150 0 0.9]);

s=[s zeros(1,600)];
S=fft(s);hold
plot([0:length(s)-1]/length(s)*500,(2/length(t))*abs(S),':');hold


