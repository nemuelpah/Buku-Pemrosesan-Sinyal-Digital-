[s,fs]=wavread('surabaya.wav');
sound(s,fs);
pause;
s=s(2e4:8e4);
%s=s(1.5e4:end);
fr=round(length(s)/220);
clear a;

for i=1:fr-1,
    s1=s((i-1)*220+1:i*220);
    a(i,:)=lpc(s1,10);
    
    y=filter(a(i,:),1,s1);
    au=xcorr(y);
    [B,I]=sort(au);
    cor1=max(au(160:200));
    if max(au(160:200))>0.1*max(au),    %B(end-1)>0.1*B(end)
        Icor=find(au==cor1);
        pitch(i)=abs(I(end)-Icor(1));
        %if pitch(i)>20,stem(au,'.');pause;end
    else
        pitch(i)=0;
    end
end
    
t=0:1/22050:30e-3;
ss1=pulstran(t,0:1/280:30e-3,'tripuls',0.001);
%ss2=-ss1;
%ss2=[zeros(1,10) ss2(1:end-10)];
%ssX=ss1+ss2;
ss=ss1+0.01*randn(1,length(ss1));
%ssNV=0.5*ssX+0.5*randn(1,length(ss));
%ssNV=0.8*randn(1,length(ss));

clear yout;
yout=[];

for i=1:fr-1,
    if pitch>0,
        y=filter(1,a(i,:),ss);
    else
        y=filter(1,a(i,:),ss);
    end
    yout=[yout y(251:250+220)];
end

yout=yout/max(yout);
%yout=yout-mean(yout);
sound(yout,fs);


