t=0:1/200:0.5;
s=3*sin(2*pi*2*t);

plot(t,s,'.','LineWidth',2,'Color',[0,0,0])

axis([-0.001 0.5 -3.5 3.5]);
xlabel('t(detik)');
ylabel('x(t)');

gtext('x(0)');
gtext('x(1)');
gtext('x(100)');
gtext('x(101)');
