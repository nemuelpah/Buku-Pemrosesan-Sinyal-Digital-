t=0:0.003:0.1;
s=0.5*sin(2*pi*25*t+0.785);
plot(t,s,'o','LineWidth',2,'Color',[0,0,0]);
grid minor;
