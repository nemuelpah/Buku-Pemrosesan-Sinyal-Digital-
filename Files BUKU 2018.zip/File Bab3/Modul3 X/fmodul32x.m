%function fmodul32
t=0:0.004:0.05;
s=0.7*cos(2*pi*20*t+0.2);
s2=0.3*cos(2*pi*50*t+0.1);
plot(t,s+s2,'.');
