s=[0 0 0 0 1 0 0 0 0];
t=[-4 -3 -2 -1 0 1 2 3 4];
stem(t,s,'LineWidth',2,'Color',[0,0,0]);hold on
axis([-4.5 4.5 0 1.5]);
xlabel('n');
ylabel('x(t) = \delta(n)');


