s=[0 1 0 0 0.5 0 0.2 0 0];
t=[0 1 2 3 4 5 6 7 8];
stem(t,s,'LineWidth',2,'Color',[0,0,0]);
axis([0 8 0 1.5]);
xlabel('n');
ylabel('x(n)');


