t=0:0.0001:0.1;
s=sin(2*pi*90*t);
t2=0:1/100:0.1;
s2=sin(2*pi*90*t2);

plot(t,s,'LineWidth',2,'Color',[0,0,0]);hold on
plot(t2,s2,'o','LineWidth',2,'Color',[0,0,0]);hold off
axis([0 0.1 -1.5 1.5]);
xlabel('t(detik)');
ylabel('s(t)');


