t=0:0.05:0.5;
s=3*sin(2*pi*2*t);

stem(t,s,'o','LineWidth',2,'Color',[0,0,0])

axis([-0.001 0.5 -3.5 3.5]);
xlabel('t(detik)');
ylabel('x(t)');

