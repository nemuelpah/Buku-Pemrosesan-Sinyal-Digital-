t=0:1/90:0.5;
s=-4*cos(2*pi*10*t+0.2*pi);
plot(t,s,'o','LineWidth',2,'Color',[0,0,0]);
grid minor;
xlabel('t(det)');
ylabel('x(n)');
