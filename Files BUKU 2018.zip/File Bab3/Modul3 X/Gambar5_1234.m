[a,fs]=wavread('ms.wav');
%plot(a)
%X=fft(a);
%stem(abs(X),'.');
s=a(1:5000);
s=decimate(s,5);

figure(1)
plot(0:length(s)-1,s);
xlabel('n');
ylabel('x(n)');
axis([0 length(s) -1.2 1.2]);

figure(2)
S=fft(s);
SA=(2/length(s))*abs(S);
SA(1)=SA(1)/2;
PS=abs(S).^2/(length(s)^2);
stem([0:length(s)-1]/length(s)*fs/5,PS,'.');
%stem([0:length(s)-1]/length(s)*fs/5,SA,'.');
%stem(0:length(s)-1,abs(S),'.');
%xlabel('k');
xlabel('f (Hz)');
%ylabel('|X(k)|');
%ylabel('|A|');
ylabel('Power (X)');
axis([0 2205 0 8e-4]);


