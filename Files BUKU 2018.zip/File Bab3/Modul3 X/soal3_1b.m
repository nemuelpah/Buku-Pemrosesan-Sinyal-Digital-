t=0:1/1000:0.03;
s=0.7*cos(2*pi*100*t+0.02*pi);
plot(t,s,'o','LineWidth',2,'Color',[0,0,0]);
grid minor;
xlabel('t(det)');
ylabel('x(n)');
