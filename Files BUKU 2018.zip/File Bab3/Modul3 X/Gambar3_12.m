s=[0 0 0 0 1 1 1 1 1];
a=0.4;
e=[0 0 0 0 1 a a^2 a^3 a^4];
t=[-4 -3 -2 -1 0 1 2 3 4];
stem(t,s.*e,'LineWidth',2,'Color',[0,0,0]);
axis([-4.5 4.5 0 1.5]);
xlabel('n');
ylabel('x(n) = 0.4^{n}u(n)');


