t=0:1/50:0.5;
s=3*sin(2*pi*2*t);

plot(t,s,'.');hold
stairs(t,s);

axis([0 0.5 -3.5 3.5]);
xlabel('t(detik)');
ylabel('x(t)');

s2=3*sin(2*pi*2*t-0.1);
plot(t,s2,':r')
hold