[s,fs]=wavread('putue.wav');

figure(1)
t=0:1/fs:(length(s)-1)/fs;
t=t';
plot(t,s,'LineWidth',2,'Color',[0,0,0]);
%axis([0 1 -1.5 1.5]);
xlabel('t (det)');
ylabel('s_1(t)');


figure(2)
[Y,F,T,P] = spectrogram(s,400,[],[],fs,'yaxis');
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; colormap(jet); view(0,90);
%axis([0 8 0 1600]);
xlabel('t (det)');
ylabel('frekuensi (Hz)');