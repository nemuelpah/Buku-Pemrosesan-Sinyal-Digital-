f1=100;
f2=20;
fs=1000;

figure(1)
t=0:1/fs:1;
s1=0.5*sin(2*pi*f1*t)+1*sin(2*pi*f2*t);
subplot(211);
plot(t,s1,'LineWidth',2,'Color',[0,0,0]);
axis([0 1 -2 2]);
xlabel('t (det)');
ylabel('s_1(t)');
line([0.125 0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([2*0.125 2*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([3*0.125 3*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([4*0.125 4*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([5*0.125 5*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([6*0.125 6*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([7*0.125 7*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])


t=0:1/fs:0.5;
s2a=0.5*sin(2*pi*f1*t);
t=0:1/fs:0.5-1/fs;
s2b=1*sin(2*pi*f2*t);
s2=[s2a s2b];
t=0:1/fs:1;
subplot(212);
plot(t,s2,'LineWidth',2,'Color',[0,0,0]);
axis([0 1 -2 2]);
xlabel('t (det)');
ylabel('s_2(t)');

line([0.125 0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([2*0.125 2*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([3*0.125 3*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([4*0.125 4*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([5*0.125 5*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([6*0.125 6*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
line([7*0.125 7*0.125],[2 -2],'LineWidth',2,'Color',[0,0,0])
