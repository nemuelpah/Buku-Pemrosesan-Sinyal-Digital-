f1=100;
f2=20;
fs=1000;

figure(1)
t=0:1/fs:1;
s1=0.5*sin(2*pi*f1*t)+1*sin(2*pi*f2*t);
subplot(211);
plot(t,s1,'LineWidth',2,'Color',[0,0,0]);
axis([0 1 -1.5 1.5]);
xlabel('t (det)');
ylabel('s_1(t)');

figure(2)
t=0:1/fs:0.5;
s2a=0.5*sin(2*pi*f1*t);
t=0:1/fs:0.5-1/fs;
s2b=1*sin(2*pi*f2*t);
s2=[s2a s2b];
t=0:1/fs:1;
subplot(211);
plot(t,s2,'LineWidth',2,'Color',[0,0,0]);
axis([0 1 -1.5 1.5]);
xlabel('t (det)');
ylabel('s_2(t)');

figure(1)
S1=fft(s1);
subplot(212);
stem([0:length(s1)-1]/length(s1)*fs,(2/length(s1))*abs(S1),'.','LineWidth',2,'Color',[0,0,0]);
xlabel('f (Hz)');
ylabel('|S_{1}(f)|');
axis([0 200 0 1.2]);

figure(2)
S2=fft(s2);
subplot(212);
stem([0:length(s2)-1]/length(s2)*fs,(2/length(s2))*abs(S2),'.','LineWidth',2,'Color',[0,0,0]);
xlabel('f (Hz)');
ylabel('|S_{2}(f)|');
axis([0 200 0 1.2]);

figure(3)
SS =spectrogram(s1,125,0,[],1000);
C=[0 0 0];
colormap(C);
waterfall(([1:129]-1)/129*500,[1:8],abs(SS'));
view(20,45);
ylabel('Segmen');
xlabel('f (Hz)');
zlabel('|S_1(f)|')

figure(6)
SS =spectrogram(s2,125,0,[],1000);
C=[0 0 0];
colormap(C);
waterfall(([1:129]-1)/129*500,[1:8],abs(SS'));
view(20,45);
ylabel('Segmen');
xlabel('f (Hz)');
zlabel('|S_2(f)|')