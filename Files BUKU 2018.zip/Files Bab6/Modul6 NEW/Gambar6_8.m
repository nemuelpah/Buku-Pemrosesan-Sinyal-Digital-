[s,fs]=wavread('dtmf.wav');
s=s';
figure(1)
t=0:1/fs:1/fs*length(s)-1/fs;
plot(t,s,'LineWidth',2,'Color',[0,0,0]);
axis([0 8 -0.8 0.8]);
xlabel('t (det)');
ylabel('s(t)');

figure(3)
[Y,F,T,P] = spectrogram(s,2000,[],[],fs,'yaxis');
surf(T,F,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; colormap(jet); view(0,90);
axis([0 8 0 1600]);
xlabel('t (det)');
ylabel('frekuensi (Hz)');