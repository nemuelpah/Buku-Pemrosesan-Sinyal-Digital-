f1=100;
f2=20;
fs=1000;

figure(1)
t=0:1/fs:0.5;
s2a=0.5*sin(2*pi*f1*t);
t=0:1/fs:0.5-1/fs;
s2b=1*sin(2*pi*f2*t);
s2=[s2a s2b];
t=0:1/fs:1;
%subplot(211);
plot(t,s2,'LineWidth',2,'Color',[0,0,0]);
axis([0 1 -1.5 1.5]);
xlabel('t (det)');
ylabel('s_2(t)');

figure(4)
spectrogram(s2,200,0,[],fs);
view(90,-90)
colorbar;