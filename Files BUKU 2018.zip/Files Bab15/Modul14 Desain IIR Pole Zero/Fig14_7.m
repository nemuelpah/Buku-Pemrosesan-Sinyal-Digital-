[p1x,p1y]=pol2cart(36/180*pi,0.8);
[z1x,z1y]=pol2cart(54/180*pi,1);
z1=z1x+z1y*j;
z2=z1x-z1y*j;
z=[z1;z2];

p1=p1x+p1y*j;
p2=p1x-p1y*j;
p=[p1;p2];

[B,A]=zp2tf(z,p,1/2.36);
[H,W] = freqz(B,A,200,10000,'whole');
plot(W,abs(H))
axis([0 10000 0 1.5]);
xlabel('f(Hz)');
ylabel('|H(f)|');