B=[1 -2 1];
A=[1 -1 0.5];
[H,W] = freqz(B,A,200,1,'whole');
plot(W,abs(H))
axis([0 1 0 2.5]);
xlabel('\Omega');
ylabel('|H|');