clear all;
X=1;
Y=1;

[p1x,p1y]=pol2cart(60/180*pi,0.8);
p1=p1x+p1y*j;
p2=p1x-p1y*j;

p1=0.5;
p2=0.5;



[z1x,z1y]=pol2cart(60/180*pi,1);
z1=z1x+z1y*j;
z2=z1x-z1y*j;

z1=0.8+0.58*j;
z2=0.8-0.58*j;

for y=-1.5:0.02:1.5,
    for x=-1.5:0.02:1.5,
        if (x+j*y-p1==0),
            H(X,Y)=1;
        elseif (x+j*y-p2==0),
            H(X,Y)=1;
        else
            H(X,Y)=((x+j*y-z1)*(x+j*y-z2))/((x+j*y-p1)*(x+j*y-p2));
        end
        
        if abs(x+j*y)>1,
            H(X,Y)=0;
        end
        
        X=X+1;
    end
    X=1;
    Y=Y+1;
end

surfl([-1.5:0.02:1.5],[-1.5:0.02:1.5],abs(H),[0,0,2]);
shading flat
%axis equal
        