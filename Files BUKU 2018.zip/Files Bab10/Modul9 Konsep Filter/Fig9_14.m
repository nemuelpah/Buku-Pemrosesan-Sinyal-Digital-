%[b,a]=butter(4,500/1000,'low');
%[b,a]=cheby1(4,1,500/1000,'low');
[b,a]=cheby2(4,10,500/1000,'low');
%[b,a]=ellip(4,0.5,20,500/1000,'low');
[H,W]=freqz(b,a);
plot(W,abs(H));

%plot(W,20*log10(abs(H)));
xlabel('f(Hz)');
ylabel('|H|');
axis([0 3 0 1.1]);