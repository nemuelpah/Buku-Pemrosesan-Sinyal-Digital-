[b,a]=butter(4,[20/100 50/100]);
[H,W]=freqz(b,a);

figure(1)
plot(W*100/pi,abs(H));
xlabel('f(Hz)');
ylabel('|H|');
axis([0 100 0 1.1]);


t=0:1/200:10-1/200;
s1=1*cos(2*pi*25*t-1); %5
s2=0.5*cos(2*pi*30*t-1);    %30
s3=0.5*cos(2*pi*45*t-1);    %30
x=s1+s2+s3;

figure(2);
X=fft(x);
stem([0:length(X)-1]/length(X)*200,2*abs(X)/length(X),'.');
axis([0 100 0 1.1]);
xlabel('f(Hz)');
ylabel('|X|');

figure(3);
y=filter(b,a,x);
Y=fft(y);
stem([0:length(Y)-1]/length(Y)*200,2*abs(Y)/length(Y),'.');
xlabel('f(Hz)');
ylabel('|Y|');
axis([0 100 0 1.1]);

