%[b,a]=butter(4,500/1000,'low');
[b,a]=cheby1(4,1,200/1000,'low');
%[b,a]=cheby2(4,10,300/1000,'low');
[b,a]=ellip(2,1.5,20,[300/1000 700/1000],'stop');
[H,W]=freqz(b,a);
plot(W*1000/pi,abs(H));

%plot(W,20*log10(abs(H)));
xlabel('f(Hz)');
ylabel('|H|');
axis([0 1000 0 1.1]);