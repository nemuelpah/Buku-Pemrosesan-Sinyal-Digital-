[b,a]=butter(6,250/1000,'low');
[H,W]=freqz(b,a,500);
%plot(W,abs(H));
plot(W*250,20*log10(abs(H)));
xlabel('f (Hz)');
ylabel('|H| (dB)');
%axis([0 3 0 1.1]);
axis([0 400 -30 5]);