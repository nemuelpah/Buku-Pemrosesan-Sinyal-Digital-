t=0:0.001:200e-3;
s1=1*sin(2*pi*10*t);
s2=0.5*sin(2*pi*80*t);
plot(s1+s2)
plot(s1)
axis([0 250 -1.5 1.5]);

[b,a]=butter(4,50/1000,'low');
[H,T]=impz(b,a);
plot(T,H);