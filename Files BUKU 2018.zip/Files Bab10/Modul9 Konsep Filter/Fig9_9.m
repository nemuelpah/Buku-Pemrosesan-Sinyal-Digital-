[b,a]=cheby1(3,0.5,400/1000,'high');
[H,W]=freqz(b,a,500);
plot(W,abs(H));
%plot(W,20*log10(abs(H)));
xlabel('f');
ylabel('|H|');
axis([0 3 0 1.1]);