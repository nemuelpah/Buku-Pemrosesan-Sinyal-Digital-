[b,a]=cheby1(6,0.5,250/1000,'low');
[H,W]=freqz(b,a,500);
plot(W,abs(H));
%plot(W,20*log10(abs(H)));
xlabel('f');
ylabel('|H|');
axis([0 3 0 1.1]);