[b,a]=cheby1(2,0.5,250/1000,'low');
[H,W]=freqz(b,a,500);
plot(W,abs(H));
hold

[b,a]=cheby1(3,0.5,250/1000,'low');
[H,W]=freqz(b,a,500);
plot(W,abs(H));

[b,a]=cheby1(4,0.5,250/1000,'low');
[H,W]=freqz(b,a,500);
plot(W,abs(H));
hold

%plot(W,20*log10(abs(H)));
xlabel('f');
ylabel('|H|');
axis([0 3 0 1.1]);