[b,a]=butter(4,80/100,'low');
[b,a]=fir1(12,80/100,'low');
%[b,a]=cheby2(10,0.5,50/100,'low');
%[b,a]=ellip(4,0.5,20,50/100,'low');
[H,W]=freqz(b,a);

figure(1)
subplot(2,1,1);
plot(W*100/pi,abs(H));
xlabel('f(Hz)');
ylabel('|H|');
grid
axis([0 100 0 1.1]);

subplot(2,1,2);
plot(W*100/pi,(angle(H)));
plot(W*100/pi,unwrap(angle(H)));
xlabel('f(Hz)');
ylabel('\phi_h');
grid

