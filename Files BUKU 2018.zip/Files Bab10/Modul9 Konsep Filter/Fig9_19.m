[b,a]=butter(4,[20/100 50/100]);
%[b,a]=cheby2(10,0.5,50/100,'low');
%[b,a]=ellip(4,0.5,20,50/100,'low');
[H,W]=freqz(b,a);

figure(1)
subplot(2,1,1);
plot(W*100/pi,abs(H));
xlabel('f(Hz)');
ylabel('|H|');
axis([0 100 0 1.1]);

subplot(2,1,2);
plot(W*100/pi,angle(H));
xlabel('f(Hz)');
ylabel('\phi_h');

figure(2);
t=0:1/200:10-1/200;
s1=1*cos(2*pi*25*t-1); %5
s2=0.5*cos(2*pi*30*t-1);    %30
s3=0.5*cos(2*pi*45*t-1);    %30
s4=0.5*cos(2*pi*30*t-1);    %30
x=s1+s2+s3+s4;
x=s1+s2+s3;

figure(2);
X=fft(x);

subplot(2,1,1);
stem([0:length(X)-1]/length(X)*200,2*abs(X)/length(X),'.');
axis([0 100 0 1.1]);
xlabel('f(Hz)');
ylabel('|X|');

subplot(2,1,2);
f=abs(X)/max(abs(X));   %untuk menghilangkan fase yang tidak penting
f=f-0.1;
f=ceil(f);
stem([0:length(X)-1]/length(X)*200,angle(X).*f,'.');
xlabel('f(Hz)');
ylabel('\phi_x');
axis([0 100 -4 4]);

figure(3);
y=filter(b,a,x);
Y=fft(y);
subplot(2,1,1);
stem([0:length(Y)-1]/length(Y)*200,2*abs(Y)/length(Y),'.');
xlabel('f(Hz)');
ylabel('|Y|');
axis([0 100 0 1.1]);

subplot(2,1,2);
f=abs(Y)/max(abs(Y));   %untuk menghilangkan fase yang tidak penting
f=f-0.1;
f=ceil(f);
stem([0:length(Y)-1]/length(Y)*200,angle(Y).*f,'.');
xlabel('f(Hz)');
ylabel('\phi_y');
axis([0 100 -4 4]);

figure(4);
t=interp(t,4);
x=interp(x,4);
y=interp(y,4);
subplot(2,1,1)
plot(t,x);
xlabel('t(s)');
ylabel('x(t)');
axis([0.1 0.3 min(y)-0.1 max(y)+0.1]);

subplot(2,1,2)
plot(t,y);
xlabel('t(s)');
ylabel('y(t)');
axis([0.1 0.3 min(y)-0.1 max(y)+0.1]);
