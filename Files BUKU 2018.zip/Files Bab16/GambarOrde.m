figure(1)
[b,a]=butter(1,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

hold on 

[b,a]=butter(2,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=butter(3,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=butter(4,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=butter(5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=butter(6,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

xlabel('\omega');
ylabel('|H| in dB');
axis([0 3 -20 0.1]);
grid minor;

gtext('N=1');
gtext('N=2');
gtext('N=3');
gtext('N=4');
gtext('N=5');
gtext('N=6');


%plot(W,20*log10(abs(H)));
%hold on

% [b,a]=cheby1(3,0.5,250/1000,'low');
% [H,W]=freqz(b,a,500);
% plot(W,abs(H));
% %plot(W,20*log10(abs(H)));
% 
% [b,a]=cheby1(4,0.5,250/1000,'low');
% [H,W]=freqz(b,a,500);
% plot(W,abs(H));
%plot(W,20*log10(abs(H)));
%hold off

%plot(W,20*log10(abs(H)));
%xlabel('f');
%ylabel('|H|');
%axis([0 3 0 1.1]);
%grid minor;
%axis([0 3 -50 0.1]);

% %==============================
% figure(2)
% [b,a]=cheby1(2,0.5,250/1000,'low');
% [H,W]=freqz(b,a,500);
% plot(W,abs(H));
% %plot(W,20*log10(abs(H)));
% hold on
% 
% [b,a]=cheby1(3,0.5,250/1000,'low');
% [H,W]=freqz(b,a,500);
% plot(W,abs(H));
% %plot(W,20*log10(abs(H)));
% 
% [b,a]=cheby1(4,0.5,250/1000,'low');
% [H,W]=freqz(b,a,500);
% plot(W,abs(H));
% %plot(W,20*log10(abs(H)));
% hold off
% 
% %plot(W,20*log10(abs(H)));
% xlabel('f');
% ylabel('|H|');
% axis([0 3 0 1.1]);
% grid minor;
% %axis([0 3 -50 0.1]);