n=1;
rp=0.5;
rs=40;
[z,p,k] = ellipap(n,rp,rs);
[num,den]=zp2tf(z,p,k);


[H,W] = freqs(num,den,200,1,'whole');
plot(W*10000,abs(H),'Color',[0 0 0],'LineWidth',2)
xlabel('f (Hz)');
ylabel('|H(f)|');