B =[0.2180   -0.4360    0.2180];
A =[1.0000    0.3514    0.3297];
[H,W] = freqz(B,A,200,1,'whole');
plot(W*10000,abs(H),'Color',[0 0 0],'LineWidth',2)
xlabel('f (Hz)');
ylabel('|H(f)|');