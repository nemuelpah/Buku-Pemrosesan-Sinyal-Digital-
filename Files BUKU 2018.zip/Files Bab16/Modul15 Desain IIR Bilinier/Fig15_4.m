B=[0.2066 0.4132 0.2066];
A=[1 -0.3695 0.1959];
[H,W] = freqz(B,A,200,1,'whole');
plot(W*10000,abs(H))
xlabel('f (Hz)');
ylabel('|H(f)|');