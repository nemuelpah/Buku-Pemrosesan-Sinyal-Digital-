n=1;
rp=0.5;
rs=20;
N=[1 2 3 4 5];

for i=1:length(N),
    [z,p,k] = ellipap(N(i),rp,rs);
    [num,den]=zp2tf(z,p,k);
    [H,W] = freqs(num,den,linspace(0,5,500));
    plot(W,20*log10(abs(H)),'Color',[0 0 0],'LineWidth',1)
    hold on;
end
hold off;
grid on

xlabel('\Omega (rad/s)');
ylabel('|H(\Omega)| dB');
title('Respon Frekuensi Prototipe Eliptic \delta_p = 0.5 dB; \delta_s = 40 dB')
axis([0 3 -25 0.5])

text(2.5,-4,'n=1');
text(2,-9,'n=2');
text(1.4,-13,'n=3');
text(1.2,-18,'n=4');
text(0.8,-19,'n=5');

