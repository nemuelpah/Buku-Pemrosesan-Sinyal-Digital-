n=1;
rp=0.5;
rs=40;
N=[1 2 3 4 5];

for i=1:length(N),
    [z,p,k] = ellipap(N(i),rp,rs);
    [num,den]=zp2tf(z,p,k);
    [H,W] = freqs(num,den,linspace(0,5,500));
    plot(W,20*log10(abs(H)),'Color',[0 0 0],'LineWidth',2)
    hold on;
end
hold off;
grid on

xlabel('\Omega (rad/s)');
ylabel('|H(\Omega)| dalam dB');
title('Respon Frekuensi Prototipe Eliptic \delta_p = 0.5 dB; \delta_s = 40 dB')

text(4,-0.5,'n=1');
text(4,-20,'n=2');
text(2,-20,'n=3');
text(1.7,-30,'n=4');
text(1,-40,'n=5');

