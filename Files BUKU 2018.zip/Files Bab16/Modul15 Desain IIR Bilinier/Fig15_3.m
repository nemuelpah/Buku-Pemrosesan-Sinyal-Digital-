[B,A]=butter(4,2*pi*2200,'s');
[H,W] = freqs(B,A,linspace(0,2*pi*10e3,500));
plot(W/(2*pi),abs(H))

[B,A]=butter(4,2000/5000);
[H,W] = freqz(B,A,100,'whole');
hold
plot(W/(2*pi)*10000,abs(H),':')
hold
axis([0 10000 0 1.2]);
xlabel('f(Hz)');
ylabel('|H|');
line([0 3000],[0.707 0.707]);
line([2000 2000],[0 0.8]);
line([2200 2200],[0 0.8]);
