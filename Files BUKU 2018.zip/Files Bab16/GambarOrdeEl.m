figure(1)

[b,a]=ellip(1,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');


hold on 

[b,a]=ellip(2,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=ellip(3,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=ellip(4,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=ellip(5,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=ellip(6,0.5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

xlabel('\omega');
ylabel('|H| in dB');
axis([0 3 -25 0.1]);
grid minor;

gtext('N=1');
gtext('N=2');
gtext('N=3');
gtext('N=4');
gtext('N=5');
gtext('N=6');
hold off


