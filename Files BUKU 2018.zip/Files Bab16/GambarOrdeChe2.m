figure(1)

[b,a]=cheby2(1,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');


hold on 

[b,a]=cheby2(2,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby2(3,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby2(4,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby2(5,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby2(6,20,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

xlabel('\omega');
ylabel('|H| in dB');
title('Prototype Chebyshev Tipe II dengan \delta_s = 20 dB');
axis([0 1.4 -30 0.1]);
grid minor;

gtext('N=1');
gtext('N=2');
gtext('N=3');
gtext('N=4');
gtext('N=5');
gtext('N=6');
hold off


