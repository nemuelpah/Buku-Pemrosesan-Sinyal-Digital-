figure(1)

[b,a]=cheby1(1,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');


hold on 

[b,a]=cheby1(2,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby1(3,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby1(4,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby1(5,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

[b,a]=cheby1(6,0.5,1/50,'low');
[H,W]=freqz(b,a,5000);
plot(W*50./pi,20*log10(abs(H)),'k-');

xlabel('\omega');
ylabel('|H| in dB');
title('Prototype Chebyshev Tipe I dengan \delta_p = 0.5 dB');
axis([0 3 -20 0.1]);
grid minor;

gtext('N=1');
gtext('N=2');
gtext('N=3');
gtext('N=4');
gtext('N=5');
gtext('N=6');
hold off


