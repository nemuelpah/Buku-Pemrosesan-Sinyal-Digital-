[s,fs]=audioread('e.wav');  %membaca dari file
sound(s,fs);
plot(s,'k-')


s=s(20000:25000-1)';
s=s-mean(s);
%fs=22050;
S=fft(s);
plot(abs(S),'k-')
axis([0 1500 0 600]);

gtext('f1');
gtext('f2');
gtext('f3');