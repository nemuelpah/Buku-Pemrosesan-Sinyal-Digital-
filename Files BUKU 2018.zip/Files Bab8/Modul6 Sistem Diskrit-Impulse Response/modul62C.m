x=[zeros(1,9) 1 zeros(1,3500)];


y=zeros(1,length(x));
for n=10:length(x),
    y(n)=8.2161e-7*x(n)+2.4648e-6*x(n-1)+2.4648e-6*x(n-2)+...
        8.2161e-7*x(n-3)+2.9623*y(n-1)-2.9253101*y(n-2)+0.9630*y(n-3);
end