load sinyal82

h(1)=1;
h(2)=1;
h(3)=1;

for n=3:1000,
    y(n)=x(n)*h(1)+x(n-1)*h(2)+x(n-2)*h(3);
end