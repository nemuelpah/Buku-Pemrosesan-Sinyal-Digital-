t=0:1/5000:0.2;
s=sin(2*pi*10*t);
s2=0.2*sin(2*pi*1000*t);
s3=s+s2;

subplot(211)
plot(t,s3,'r-')
b=fir1(10,800/2500,'high');
y=filter(b,1,s3);

subplot(212)
plot(t,y)
axis([0 0.2 -2 2]);