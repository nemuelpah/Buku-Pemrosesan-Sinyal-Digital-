load sinyal42

h(1)=1;
h(2)=1;

for n=2:1000,
    y(n)=x(n)*h(1)+x(n-1)*h(2);
end