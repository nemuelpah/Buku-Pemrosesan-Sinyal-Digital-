t=0:0.001:2;
t=0:0.01:2;
t=0:0.05:2;
x=3*cos(2*pi*2*t-1.2*pi);
plot(t,x)
plot(t,x,'-+')
plot(t,x,'.')
stem(t,x,'.')
xlabel('t(detik)');
ylabel('x(t)');
title('x(t)=3 cos (2 \pi 2 t -1.2 \pi)');
axis([0 2 -4 4]);
