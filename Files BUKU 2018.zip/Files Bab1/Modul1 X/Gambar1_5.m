t=0:0.01:1;
s=sin(2*pi*1*t);

plot(t,s,'.')
axis([0 1 -1.1 1.1]);