t=0:0.001:4;
s=3*cos ( 2*pi*2*t - 1.2*pi);
s2=1*sin(2*pi*4.5*t);
s3=s+s2;
s4=s.*s2;

subplot(3,2,1);
plot(t,s)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_1(t)');

subplot(3,2,2);
plot(t,s)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_1(t)');

subplot(3,2,3);
plot(t,s2)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_2(t)');

subplot(3,2,4);
plot(t,s2)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_2(t)');

subplot(3,2,5);
plot(t,s3)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_3(t)=s_1(t)+s_2(t)');

subplot(3,2,6);
plot(t,s4)
axis([0 4 -5 5]);
xlabel('t(detik)');
ylabel('s_4(t)=s_1(t)*s_2(t)');
