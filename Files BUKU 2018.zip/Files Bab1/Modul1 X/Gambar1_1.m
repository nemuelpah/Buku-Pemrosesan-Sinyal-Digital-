load sinyal1_1
plot(t,s')
xlabel('t');
ylabel('Amplitudo');