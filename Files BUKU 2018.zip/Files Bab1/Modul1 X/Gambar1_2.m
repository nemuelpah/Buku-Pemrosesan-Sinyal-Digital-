load ECG
aa(:,2)=aa(:,2)-mean(aa(:,2));
plot(aa(:,1),aa(:,2))
xlabel('t (det)');
ylabel('ECG(t)');
grid on