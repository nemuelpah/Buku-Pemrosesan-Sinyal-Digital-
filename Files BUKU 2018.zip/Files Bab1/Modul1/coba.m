t=0:0.0001:2;
x=sin(2*pi*2*t);
%plot(t,x);
t2=0:0.0001:1;
x2=cos(2*pi*2*t2);

plot(t2,x2)