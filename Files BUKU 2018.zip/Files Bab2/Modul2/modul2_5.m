load sinyal2_7      % anda dapat mengganti nama sinyal ini

plot(t,s);
xlabel('t (det)');
ylabel('s(t)');
pause

fs=1/(t(2)-t(1));
S=fft(s);
stem([0:length(S)-1]/length(S)*fs,2*abs(S)/length(S),'.');
axis([0 fs/2 0 5]);
xlabel('f(Hz)');
ylabel('S(t)');
pause

stem([0:length(S)-1]/length(S)*fs,angle(S),'.');
axis([0 fs/2 -pi pi]);
xlabel('f(Hz)');
ylabel('Fase S(t)');
