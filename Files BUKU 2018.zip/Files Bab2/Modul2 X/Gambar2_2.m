t=0:0.001:1;
x=3*sin(2*pi*3.5*t-0.4*pi);
plot(t,x,'LineWidth',2,'Color',[0,0,0]);
xlabel('t');
ylabel('x(t)');
axis([0 1 -4 4]);
grid on;