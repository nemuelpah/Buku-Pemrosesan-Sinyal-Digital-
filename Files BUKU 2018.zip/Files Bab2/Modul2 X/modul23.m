t=0:0.00001:1-0.00001;
s=-0.85*sin(2*pi*700*t+0.1*pi);
s=-0.85*sin(2*pi*700*t+0.1*pi);
plot(t,s);
xlabel('t');
ylabel('s(t)');
axis([0 4e-3 -1 1]);
grid on