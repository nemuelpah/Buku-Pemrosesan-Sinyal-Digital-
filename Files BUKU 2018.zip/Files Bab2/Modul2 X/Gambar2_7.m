t=0:1/250:0.5-0.0001;
x=3*cos(2*pi*10*t-0.2*pi);

subplot(221);
plot(t,x,'LineWidth',2,'Color',[0,0,0]);
xlabel('t');
ylabel('x(t)');
title('DOMAIN WAKTU');
axis([0 0.5 -4 4]);
grid on

X=fft(x);
XA=(2/length(X))*abs(X);
XA(1)=XA(1)/2;
subplot(222);
stem([0:length(X)-1]/length(X)*250,XA,'.','LineWidth',2,'Color',[0,0,0]);
axis([0 25 0 4]);
xlabel('f (Hz)');
ylabel('Amplitudo X(f)');
title('DOMAIN FREKUENSI');

subplot(224);
XP=round(abs(X))./round(abs(X));
theta=angle(X).*XP;
stem([0:length(X)-1]/length(X)*250,theta,'.','LineWidth',2,'Color',[0,0,0]);
axis([0 25 -2 2]);
xlabel('f (Hz)');
ylabel('Fase \theta(f)');