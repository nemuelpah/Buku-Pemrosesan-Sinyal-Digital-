t=-1:0.001:1-0.001;
s=t;

s=[s s s s s];
t=-5:0.001:5-0.001;

subplot(221);
plot(t,s,'LineWidth',2,'Color',[0,0,0]);
xlabel('t');
ylabel('s(t)');
title('DOMAIN WAKTU');
axis([-5 5 -2 2]);
grid on

subplot(222);
stem([0.5 1 1.5 2 2.5 3],[0.6366 0.3183 0.2122 0.1592 0.1273 0.1061],'.','LineWidth',2,'Color',[0,0,0]);
axis([0 3.5 0 0.8]);
xlabel('f (Hz)');
ylabel('Amplitudo S(f)');
title('DOMAIN FREKUENSI');

subplot(224);
stem([0.5 1 1.5 2 2.5 3],[-1.57 1.57 -1.57 1.57 -1.57 1.57],'.','LineWidth',2,'Color',[0,0,0]);
axis([0 3.5 -2 2]);
xlabel('f (Hz)');
ylabel('Fase \theta(f)');