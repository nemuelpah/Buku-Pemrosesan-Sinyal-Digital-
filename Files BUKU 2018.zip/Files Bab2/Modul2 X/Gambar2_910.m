t=0:0.001:10-0.001;
s=sinc(t);
s=s-mean(s);
ss=s;
SS=fft(ss);

figure(1)
subplot(221);
plot(t,ss,'LineWidth',2,'Color',[0,0,0]);
xlabel('t');
ylabel('s(t)');
grid on;


subplot(222)
stem([0:length(s)-1]/length(s)*1000,abs(SS)*2/length(SS),'.','LineWidth',2,'Color',[0,0,0])
axis([0 20 0 0.2]);
xlabel('f (Hz)');
ylabel('Amplitudo S(f)');

subplot(224)
stem([0:length(s)-1]/length(s)*1000,angle(SS),'.','LineWidth',2,'Color',[0,0,0])
%axis([0 20 -2 2]);
xlabel('f (Hz)');
ylabel('Fase \theta(f)');

figure(2)
subplot(221);
plot(t,ss,'LineWidth',2,'Color',[0,0,0]);
xlabel('t');
ylabel('s(t)');
grid on;

subplot(2,2,2)
plot([0:length(s)-1]/length(s)*1000,abs(SS)*2/length(SS),'LineWidth',2,'Color',[0,0,0])
axis([0 20 0 0.2]);
xlabel('f (Hz)');
ylabel('Amplitudo S(f)');

subplot(2,2,4)
plot([0:length(s)-1]/length(s)*1000,angle(SS),'LineWidth',2,'Color',[0,0,0])
%axis([0 20 -2 2]);
xlabel('f (Hz)');
ylabel('Fase \theta(f)');
