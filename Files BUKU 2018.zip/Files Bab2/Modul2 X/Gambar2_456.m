t=-1:0.001:1-0.001;
s=t;

s=[s s s s s];
t=-5:0.001:5-0.001;

plot(t,s)
axis([-5 5 -2 2]);
grid on
xlabel('t');
ylabel('s(t)');

pause;

s1=2/pi*sin(2*pi*0.5*t);
s2=-2/(2*pi)*sin(2*2*pi*0.5*t);
s3=2/(3*pi)*sin(3*2*pi*0.5*t);
s4=-2/(4*pi)*sin(4*2*pi*0.5*t);
s5=2/(5*pi)*sin(5*2*pi*0.5*t);
s6=-2/(6*pi)*sin(6*2*pi*0.5*t);
s7=2/(7*pi)*sin(7*2*pi*0.5*t);
s8=-2/(8*pi)*sin(8*2*pi*0.5*t);

subplot(6,1,1)
plot(t,s1)
axis([-5 5 -2 2]);
ylabel('S1');

subplot(6,1,2)
plot(t,s2)
axis([-5 5 -2 2]);
ylabel('S2');

subplot(6,1,3)
plot(t,s3)
axis([-5 5 -2 2]);
ylabel('S3');

subplot(6,1,4)
plot(t,s4)
axis([-5 5 -2 2]);
ylabel('S4');

subplot(6,1,5)
plot(t,s5)
axis([-5 5 -2 2]);
ylabel('S5');

subplot(6,1,6)
plot(t,s6)
axis([-5 5 -2 2]);
ylabel('S6');

%---------
subplot(6,1,1)
plot(t,s,t,s1)
axis([-5 5 -2 2]);
gtext('S1');

subplot(6,1,2)
plot(t,s,t,s1+s2)
axis([-5 5 -2 2]);
gtext('S1+S2');

subplot(6,1,3)
plot(t,s,t,s1+s2+s3)
axis([-5 5 -2 2]);
gtext('S1+S2+S3');

subplot(6,1,4)
plot(t,s,t,s1+s2+s3+s4)
axis([-5 5 -2 2]);
gtext('S1+S2+S3+S4');

subplot(6,1,5)
plot(t,s,t,s1+s2+s3+s4+s5)
axis([-5 5 -2 2]);
gtext('S1+S2+S3+S4+S5');

subplot(6,1,6)
plot(t,s,t,s1+s2+s3+s4+s5+s6)
axis([-5 5 -2 2]);
gtext('S1+S2+s3+s4+s5+S6');
