f=500*2*pi;
f=6000;
f=1200;
f=1000;
A=2.0;
A=2.5
ph=pi/2;
ph=-0.7;

subplot(2,1,1);
stem(f,A,'o');
xlabel('\omega(rad/s)');
xlabel('f (Hz)');
ylabel('S(t)');
axis([0 3e3*2*pi 0 3]);
axis([0 3000 0 3]);
grid on

subplot(2,1,2);
stem(f,ph,'o');
xlabel('\omega(rad/s)');
xlabel('f (Hz)');
ylabel('Fase S(t)');
axis([0 3e3*2*pi -pi pi]);
axis([0 3000 -pi pi]);
axis([0 3000 -1 1]);
grid on